INFORMATION
 * VERSION: 1.18.0
 * DATE: 2024-10-09
 * UPDATES AND DOCS AT: http://wolfstudiostecsupport.com
 * 
 * @license Copyright (c) 2020-2024, WolfStudios. All rights reserved.
 * 
 * @author: WolfStudios, wolfstudisofilms@gmail.com
